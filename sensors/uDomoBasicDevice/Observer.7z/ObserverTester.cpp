#include "ObserverTester.h"
#include "Subject.h"

void ObserverTester::onReceivedDataFromSubject(const Subject *sub) {
    //Serial.print("Value is "); Serial.println(sub->getValue());
}
