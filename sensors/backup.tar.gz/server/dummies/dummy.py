import time
import sys
import json

for index in range(0, 12300):
	time.sleep(0.4)
	
	#Readings object
	Readings = {}
	
	#Sensor (Readings.Sensor)
	Sensor = {}
	Sensor["Temperature"] = index 
	Sensor["Pressure"] = index * 2
	Sensor["Altitude"] = index * 2.5
	
	#Server (Readings.Server)
	Server = {}
	Server["PublicIP"] =  "192.168.1.1"
	Server["Temperature"] = index * 1.5
	
	#Light object (Readings.Light)
	Light = {}
	Light["maxIn"] = 300
	Light["maxOut"] = 600
	Light["readValue"] = index
	
	Sensor["Light"] = Light #Add Light object to Sensor object
	
	Readings["Server"] = Server #Add Server object to Readings object
	Readings["Sensor"] = Sensor #Add Sensor object to Readings object
	
	print json.dumps(Readings)
	sys.stdout.flush()