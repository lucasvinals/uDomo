module.exports = {
        getReadings : function(){
            var Readings = {}, Sensor = {}, Server = {}, Light = {}, i = Math.floor((Math.random() * 100) + 1);
    
            Sensor.Temperature = i;
            Sensor.Pressure = i * 1.5;
            Sensor.Altitude = i * 1.7;

            Server.PublicIP = "192.168.0.1";
            Server.Temperature = i;

            Light.maxIn = 300;
            Light.maxOut = 600;
            Light.readValue = i * 2;

            Sensor.Light = Light;
            Readings.Server = Server;
            Readings.Sensor = Sensor;
            return Readings;
        }
}; 