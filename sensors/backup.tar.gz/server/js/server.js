/* Test how fast can this library handle request, if possible, chain functions so it returns the result as fast as them end */

var Cylon = require('cylon');

Cylon.robot({
  connections: {
    raspi: { adaptor: 'raspi' }
  },
  devices: {
    bmp180: { driver: 'bmp180' }
  },

//  work: function(sensor) {
//    sensor.bmp180.getTemperature(function(err, val) {
//      if (err) {
//        console.log(err);
//        return;
//      }
//
//      console.log("getTemperature call:");
//      console.log("\tTemp: " + val.temp + " °C");
//    });
//
//    after((1).second(), function() {
//      sensor.bmp180.getPressure(1, function(err, val) {
//        if (err) {
//          console.log(err);
//          return;
//        }
//
//        console.log("getPressure call:");
//        console.log("\tTemperature: " + val.temp + " C");
//        console.log("\tPressure: " + val.press + " Pa");
//      });
//    });
//
//    after((2).seconds(), function() {
//      sensor.bmp180.getAltitude(1, null, function(err, val) {
//        if (err) {
//          console.log(err);
//          return;
//        }
//
//        console.log("getAltitude call:");
//        console.log("\tTemperature: " + val.temp + " C");
//        console.log("\tPressure: " + val.press + " Pa");
//        console.log("\tAltitude: " + val.alt + " m");
//      });
//    });
//  }
    
    
    work: function(sensor){
        var Readings = {};
        sensor.bmp180.getTemperature(function(err, val) {Readings.Temperature = val;});
        sensor.bmp180.getPressure(1, function(err, val){Readings.Pressure = val;});
        sensor.bmp180.getAltitude(1, null, function(err, val) {Readings.Altitude = val;});
        return Readings;
    }
}).start();

module.exports = {getReadings : Cylon.robot.work};